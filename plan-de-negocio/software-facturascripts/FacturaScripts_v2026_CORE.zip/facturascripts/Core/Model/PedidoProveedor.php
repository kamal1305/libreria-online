<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2014-2026  Carlos Garcia Gomez     <carlos@facturascripts.com>
 * Copyright (C) 2014-2015  Francesc Pineda Segarra <shawe.ewahs@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Model;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Model\Base\PurchaseDocument;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\LineaPedidoProveedor as LineaPedido;

/**
 * Supplier order.
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class PedidoProveedor extends PurchaseDocument
{
    use ModelTrait;

    /** @var int Identificador único del pedido de proveedor. */
    public $idpedido;

    /**
     * Returns the lines associated with the order.
     *
     * @return LineaPedido[]
     */
    public function getLines(): array
    {
        $order = ['orden' => 'DESC', 'idlinea' => 'ASC'];
        return LineaPedido::allWhereEq('idpedido', $this->idpedido, $order);
    }

    /**
     * Returns a new line for this document.
     *
     * @param array $data
     * @param array $exclude
     *
     * @return LineaPedido
     */
    public function getNewLine(array $data = [], array $exclude = ['actualizastock', 'idlinea', 'idpedido', 'servido'])
    {
        $newLine = new LineaPedido();
        $newLine->actualizastock = $this->getStatus()->actualizastock;
        $newLine->excepcioniva = $this->getSubject()->excepcioniva;
        $newLine->idpedido = $this->idpedido;
        $newLine->irpf = $this->irpf;
        $newLine->loadFromData($data, $exclude);

        // si no viene de getNewProductLine(), calculamos la línea
        if (empty($data['referencia'] ?? '')) {
            Calculator::calculateLine($this, $newLine);
        }

        // allow extensions
        $this->pipe('getNewLine', $newLine, $data, $exclude);

        return $newLine;
    }

    public static function primaryColumn(): string
    {
        return 'idpedido';
    }

    public static function tableName(): string
    {
        return 'pedidosprov';
    }
}
