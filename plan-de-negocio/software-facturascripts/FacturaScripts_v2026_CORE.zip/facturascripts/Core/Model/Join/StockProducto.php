<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Model\Join;

use FacturaScripts\Core\Template\JoinModel;
use FacturaScripts\Dinamic\Model\Producto;

/**
 * Modelo Stock con datos del Producto y de la Variante. Combina las tablas
 * stocks, variantes y productos para listar el stock con su descripción,
 * coste, precio y valor total (cantidad por coste), con Producto como
 * modelo master.
 *
 * @author Raul Jimenez                     <raul.jimenez@nazcanetworks.com>
 * @author Jose Antonio Cuello Principal    <yopli2000@gmail.com>
 * @author Carlos García Gómez              <carlos@facturascripts.com>
 */
class StockProducto extends JoinModel
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->setMasterModel(new Producto());
    }

    public function getModelFields(): array
    {
        $fields = parent::getModelFields();
        // forzamos el tipo de la columna total, ya que es una columna calculada
        // (cantidad * coste) que no existe en las tablas y quedaría sin tipo
        $fields['total']['type'] = 'double';
        return $fields;
    }

    protected function getFields(): array
    {
        return [
            'cantidad' => 'stocks.cantidad',
            'codalmacen' => 'stocks.codalmacen',
            'codfabricante' => 'productos.codfabricante',
            'codfamilia' => 'productos.codfamilia',
            'coste' => 'variantes.coste',
            'descripcion' => 'productos.descripcion',
            'disponible' => 'stocks.disponible',
            'idproducto' => 'stocks.idproducto',
            'idstock' => 'stocks.idstock',
            'precio' => 'variantes.precio',
            'pterecibir' => 'stocks.pterecibir',
            'referencia' => 'stocks.referencia',
            'reservada' => 'stocks.reservada',
            'stockmax' => 'stocks.stockmax',
            'stockmin' => 'stocks.stockmin',
            'total' => 'stocks.cantidad*variantes.coste',
            'ubicacion' => 'stocks.ubicacion',
        ];
    }

    protected function getSQLFrom(): string
    {
        return 'stocks'
            . ' LEFT JOIN variantes ON variantes.referencia = stocks.referencia'
            . ' LEFT JOIN productos ON productos.idproducto = variantes.idproducto';
    }

    protected function getTables(): array
    {
        return ['productos', 'stocks', 'variantes'];
    }
}
