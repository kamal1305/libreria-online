<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2014-2026  Carlos Garcia Gomez     <carlos@facturascripts.com>
 * Copyright (C) 2014       Francesc Pineda Segarra <shawe.ewahs@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Model;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\LineaPresupuestoCliente as LineaPresupuesto;

/**
 * Customer estimation.
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class PresupuestoCliente extends SalesDocument
{
    use ModelTrait;

    /** @var string Fecha hasta la que se mantiene la validez del presupuesto. */
    public $finoferta;

    /** @var integer Identificador único del presupuesto de cliente. */
    public $idpresupuesto;

    public function clear(): void
    {
        parent::clear();

        // set default expiration
        $expirationDays = Tools::settings('default', 'finofertadays');
        if ($expirationDays) {
            $this->finoferta = Tools::date('+' . $expirationDays . ' days');
        }
    }

    /**
     * Returns the lines associated with the estimation.
     *
     * @return LineaPresupuesto[]
     */
    public function getLines(): array
    {
        $orderBy = ['orden' => 'DESC', 'idlinea' => 'ASC'];
        return LineaPresupuesto::allWhereEq('idpresupuesto', $this->idpresupuesto, $orderBy);
    }

    /**
     * Returns a new line for this document.
     *
     * @param array $data
     * @param array $exclude
     *
     * @return LineaPresupuesto
     */
    public function getNewLine(array $data = [], array $exclude = ['actualizastock', 'idlinea', 'idpresupuesto', 'servido'])
    {
        $newLine = new LineaPresupuesto();
        $newLine->actualizastock = $this->getStatus()->actualizastock;
        $newLine->excepcioniva = $this->getSubject()->excepcioniva;
        $newLine->idpresupuesto = $this->idpresupuesto;
        $newLine->irpf = $this->irpf;
        $newLine->loadFromData($data, $exclude);

        // si no viene de getNewProductLine(), calculamos la línea
        if (empty($data['referencia'] ?? '')) {
            Calculator::calculateLine($this, $newLine);
        }

        // allow extensions
        $this->pipe('getNewLine', $newLine, $data, $exclude);

        return $newLine;
    }

    public static function primaryColumn(): string
    {
        return 'idpresupuesto';
    }

    public static function tableName(): string
    {
        return 'presupuestoscli';
    }

    public function test(): bool
    {
        // finoferta can't be previous to fecha
        if (!empty($this->finoferta) && strtotime($this->finoferta) < strtotime($this->fecha)) {
            $this->finoferta = null;
        }

        return parent::test();
    }
}
