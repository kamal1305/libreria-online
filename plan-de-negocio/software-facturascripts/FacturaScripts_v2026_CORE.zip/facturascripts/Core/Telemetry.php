<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2019-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core;

use Exception;
use FacturaScripts\Core\Base\DataBase;

/**
 * This class allow sending telemetry data to the master server,
 * ONLY if the user has registered this installation.
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
final class Telemetry
{
    const TELEMETRY_URL = 'https://facturascripts.com/Telemetry';

    /** Weekly update*/
    const UPDATE_INTERVAL = 604800;

    /** @var int */
    private $id_install;

    /** @var int */
    private $last_update;

    /** @var string */
    private $sign_key;

    public function __construct()
    {
        $this->id_install = (int)Tools::settings('default', 'telemetryinstall');
        $this->last_update = (int)Tools::settings('default', 'telemetrylastu');
        $this->sign_key = Tools::settings('default', 'telemetrykey');
    }

    public function claimUrl(): string
    {
        $params = $this->collectData(true);
        $params['action'] = 'claim';

        $this->calculateHash($params);

        return self::TELEMETRY_URL . '?' . http_build_query($params);
    }

    public function getMetadata(): array
    {
        if (false === $this->ready() || empty($this->sign_key)) {
            return [];
        }

        $params = $this->collectData();
        $params['action'] = 'get-metadata';

        $this->calculateHash($params);

        // hacemos una petición a la url de telemetría
        $request = Http::get(self::TELEMETRY_URL, $params)->setTimeout(10);
        if ($request->failed()) {
            return [];
        }

        // comprobamos que la petición ha devuelto un json
        $data = $request->json();
        if (empty($data) || empty($data['data'] ?? '')) {
            return [];
        }

        return $data['data'] ?? [];
    }

    public function id()
    {
        return $this->id_install;
    }

    public static function init(): self
    {
        return new self();
    }

    public function install(): bool
    {
        if ($this->id_install) {
            return true;
        }

        $params = $this->collectData();
        $params['action'] = 'install';

        // hacemos una petición a la url de telemetría
        $request = Http::post(self::TELEMETRY_URL, $params)->setTimeout(10);
        if ($request->failed()) {
            return false;
        }

        // comprobamos que la petición ha devuelto un json
        $data = $request->json();
        if (empty($data) || empty($data['idinstall'] ?? '')) {
            return false;
        }

        // guardamos los datos de la instalación
        $this->id_install = $data['idinstall'];
        $this->sign_key = $data['signkey'];
        return $this->save();
    }

    public function ready(): bool
    {
        return !empty($this->id_install);
    }

    public function signUrl(string $url): string
    {
        if (empty($this->id_install)) {
            return $url;
        }

        $params = $this->collectData(true);
        $this->calculateHash($params);

        return $url . '?' . http_build_query($params);
    }

    public function unlink(): bool
    {
        if (empty($this->id_install)) {
            return true;
        }

        $params = $this->collectData();
        $params['action'] = 'unlink';

        $this->calculateHash($params);

        // hacemos una petición a la url de telemetría
        $request = Http::get(self::TELEMETRY_URL, $params)->setTimeout(10);
        if ($request->failed()) {
            return false;
        }

        // comprobamos que la petición ha devuelto un json
        $data = $request->json();
        if (isset($data['error']) && $data['error']) {
            return false;
        }

        // eliminamos los datos de la instalación
        $this->id_install = null;
        Tools::settingsSet('default', 'telemetryinstall', null);
        Tools::settingsSet('default', 'telemetrylastu', null);
        Tools::settingsSet('default', 'telemetrykey', null);

        return Tools::settingsSave();
    }

    public function update(): bool
    {
        if (false === $this->ready() || time() - $this->last_update < self::UPDATE_INTERVAL) {
            return false;
        }

        $params = $this->collectData();
        $params['action'] = 'update';

        $this->calculateHash($params);

        // hacemos una petición a la url de telemetría
        $request = Http::post(self::TELEMETRY_URL, $params)->setTimeout(3);
        if ($request->failed()) {
            $this->save();
            return false;
        }

        // comprobamos que la petición ha devuelto un json
        $data = $request->json();
        if (empty($data) || !isset($data['ok']) || !$data['ok']) {
            $this->save();
            return false;
        }

        return $this->save();
    }

    public function url(): string
    {
        // preferimos la url configurada, y si no, la del host de la petición;
        // en cli (cron) no hay host, así que enviamos vacío en lugar del
        // localhost por defecto para no dar una señal falsa al servidor
        $url = Tools::settings('default', 'site_url', '');
        if (!empty($url)) {
            return $url;
        }

        return array_key_exists('HTTP_HOST', $_SERVER) ? Tools::siteUrl() : '';
    }

    private function calculateHash(array &$data): void
    {
        $data['hash'] = sha1($data['randomnum'] . $this->sign_key);
    }

    private function collectData(bool $minimum = false): array
    {
        $data = [
            'codpais' => Tools::settings('default', 'codpais'),
            'coreversion' => Kernel::version(),
            'idinstall' => $this->id_install,
            'langcode' => Tools::config('lang'),
            'phpversion' => (float)PHP_VERSION,
            'randomnum' => mt_rand()
        ];

        if (false === $minimum) {
            $data['dbengine'] = $this->getDatabaseEngine();
            $data['fingerprints'] = $this->collectFingerprints();
            $data['os'] = PHP_OS;
            $data['pluginlist'] = implode(',', Plugins::enabled());
            $data['url'] = $this->url();
        }

        return $data;
    }

    private function collectFingerprints(): string
    {
        $fingerprints = [];
        foreach (Plugins::list() as $plugin) {
            $path = Tools::folder('Plugins', $plugin->name, '.fingerprint');
            if (file_exists($path)) {
                $content = trim(file_get_contents($path));
                if (!empty($content)) {
                    $fingerprints[] = $content;
                }
            }
        }
        return implode(',', $fingerprints);
    }

    private function getDatabaseEngine(): string
    {
        try {
            $db = new DataBase();
            return $db->type();
        } catch (Exception $e) {
            return '';
        }
    }

    private function save(): bool
    {
        // sumamos un jitter aleatorio (hasta 1 día) para desincronizar las
        // peticiones entre instalaciones y evitar picos en los mismos días/horas
        $this->last_update = time() + mt_rand(0, 86400);

        Tools::settingsSet('default', 'telemetryinstall', $this->id_install);
        Tools::settingsSet('default', 'telemetrykey', $this->sign_key);
        Tools::settingsSet('default', 'telemetrylastu', $this->last_update);

        return Tools::settingsSave();
    }
}
