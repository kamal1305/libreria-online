<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Controller;

use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Where;

/**
 * Controlador para editar un único elemento del modelo LogMessage
 *
 * @author Francesc Pineda Segarra  <francesc.pineda.segarra@gmail.com>
 * @author Carlos García Gómez      <carlos@facturascripts.com>
 */
class EditLogMessage extends EditController
{
    public function getModelClassName(): string
    {
        return 'LogMessage';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'admin';
        $data['title'] = 'log';
        $data['icon'] = 'fa-solid fa-file-medical-alt';
        return $data;
    }

    /**
     * Loads views.
     */
    protected function createViews()
    {
        parent::createViews();

        // desactivamos los botones nuevo y opciones
        $this->mainTab()
            ->setSettings('btnNew', false)
            ->setSettings('btnOptions', false);

        // añadimos la pestaña de logs
        $this->createViewsOtherLogs();

        // colocamos las pestañas abajo
        $this->setTabsPosition('bottom');
    }

    protected function createViewsOtherLogs(string $viewName = 'ListLogMessage')
    {
        $this->addListView($viewName, 'LogMessage', 'related', 'fa-solid fa-file-medical-alt')
            ->addSearchFields(['ip', 'message', 'uri'])
            ->addOrderBy(['time', 'id'], 'date', 2)
            ->addOrderBy(['level'], 'level')
            // desactivamos el botón nuevo
            ->setSettings('btnNew', false);
    }

    /**
     * Load view data procedure
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'ListLogMessage':
                $code = $this->mainTabModelValue('id');
                $ipAddress = $this->mainTabModelValue('ip');
                $where = [
                    Where::notEq('id', $code),
                    Where::eq('ip', $ipAddress)
                ];
                $view->loadData('', $where);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }
}
