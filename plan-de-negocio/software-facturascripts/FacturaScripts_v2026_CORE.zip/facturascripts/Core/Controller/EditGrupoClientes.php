<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Controller;

use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\DataSrc\Retenciones;
use FacturaScripts\Core\DataSrc\Series;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Lib\ExtendedController\EditController;
use FacturaScripts\Dinamic\Model\Cliente;

/**
 * Controlador para editar un único elemento del modelo GrupoClientes
 *
 * @author Carlos García Gómez           <carlos@facturascripts.com>
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 * @author Nazca Networks                <comercial@nazcanetworks.com>
 * @author Cristo M. Estévez Hernández   <cristom.estevez@gmail.com>
 */
class EditGrupoClientes extends EditController
{
    public function getModelClassName(): string
    {
        return 'GrupoClientes';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'customer-group';
        $data['icon'] = 'fa-solid fa-users-cog';
        return $data;
    }

    protected function addCustomerAction()
    {
        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return;
        }

        $num = 0;
        $cliente = new Cliente();
        foreach ($codes as $code) {
            if (false === $cliente->loadFromCode($code)) {
                return;
            }

            $cliente->codgrupo = $this->request->query('code');
            if ($cliente->save()) {
                $num++;
            }
        }

        Tools::log()->notice('items-added-correctly', ['%num%' => $num]);
    }

    /**
     * Load views
     */
    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        $this->createViewCustomers();
        $this->createViewNewCustomers();
    }

    /**
     * @param string $viewName
     */
    protected function createViewCommon(string $viewName)
    {
        $values = [
            ['label' => Tools::trans('only-active'), 'where' => [Where::eq('debaja', false)]],
            ['label' => Tools::trans('only-suspended'), 'where' => [Where::eq('debaja', true)]],
            ['label' => Tools::trans('all'), 'where' => []]
        ];

        $this->listView($viewName)
            ->addOrderBy(['codcliente'], 'code')
            ->addOrderBy(['email'], 'email')
            ->addOrderBy(['fechaalta'], 'creation-date')
            ->addOrderBy(['nombre'], 'name', 1)
            ->addOrderBy(['riesgoalcanzado'], 'current-risk')
            ->addSearchFields(['cifnif', 'codcliente', 'email', 'nombre', 'observaciones', 'razonsocial', 'telefono1', 'telefono2'])
            // filtros
            ->addFilterSelectWhere('status', $values)
            ->addFilterSelect('codserie', 'series', 'codserie', Series::codeModel())
            ->addFilterSelect('codretencion', 'retentions', 'codretencion', Retenciones::codeModel())
            ->addFilterSelect('codpago', 'payment-methods', 'codpago', FormasPago::codeModel())
            // ocultamos la columna grupo y desactivamos los botones de nuevo y eliminar
            ->disableColumn('group')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false);
    }

    /**
     * @param string $viewName
     */
    protected function createViewCustomers(string $viewName = 'ListCliente')
    {
        $this->addListView($viewName, 'Cliente', 'customers', 'fa-solid fa-users');
        $this->createViewCommon($viewName);

        // add action button
        $this->tab($viewName)->addButton([
            'action' => 'remove-customer',
            'color' => 'danger',
            'confirm' => true,
            'icon' => 'fa-solid fa-folder-minus',
            'label' => 'remove-from-list'
        ]);
    }

    /**
     * @param string $viewName
     */
    protected function createViewNewCustomers(string $viewName = 'ListCliente-new')
    {
        $this->addListView($viewName, 'Cliente', 'add', 'fa-solid fa-user-plus');
        $this->createViewCommon($viewName);

        // add action button
        $this->tab($viewName)->addButton([
            'action' => 'add-customer',
            'color' => 'success',
            'icon' => 'fa-solid fa-folder-plus',
            'label' => 'add'
        ]);
    }

    /**
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'add-customer':
                $this->addCustomerAction();
                return true;

            case 'remove-customer':
                $this->removeCustomerAction();
                return true;
        }

        return parent::execPreviousAction($action);
    }

    /**
     * Procedure responsible for loading the data to be displayed.
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $codgrupo = $this->tabModelValue('EditGrupoClientes', 'codgrupo');
        switch ($viewName) {
            case 'ListCliente':
                $where = [Where::eq('codgrupo', $codgrupo)];
                $view->loadData('', $where);
                break;

            case 'ListCliente-new':
                $where = [Where::isNull('codgrupo')];
                $view->loadData('', $where);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    protected function removeCustomerAction()
    {
        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return;
        }

        $num = 0;
        $cliente = new Cliente();
        foreach ($codes as $code) {
            if (false === $cliente->loadFromCode($code)) {
                return;
            }

            $cliente->codgrupo = null;
            if ($cliente->save()) {
                $num++;
            }
        }

        Tools::log()->notice('items-removed-correctly', ['%num%' => $num]);
    }
}
