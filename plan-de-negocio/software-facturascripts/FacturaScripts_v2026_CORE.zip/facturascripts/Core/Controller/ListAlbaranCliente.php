<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Controller;

use FacturaScripts\Core\DataSrc\Paises;
use FacturaScripts\Core\Lib\ExtendedController\ProvinceCityFilterTrait;
use FacturaScripts\Dinamic\Lib\ExtendedController\ListBusinessDocument;

/**
 * Controlador para listar los elementos del modelo AlbaranCliente
 *
 * @author Carlos García Gómez           <carlos@facturascripts.com>
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 * @author Cristo M. Estévez Hernández   <cristom.estevez@gmail.com>
 */
class ListAlbaranCliente extends ListBusinessDocument
{
    use ProvinceCityFilterTrait;

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'delivery-notes';
        $data['icon'] = 'fa-solid fa-dolly-flatbed';
        return $data;
    }

    /**
     * Load views
     */
    protected function createViews()
    {
        $this->createViewsAlbaranes();

        if ($this->permissions->onlyOwnerData === false) {
            $this->createViewLines('ListLineaAlbaranCliente', 'LineaAlbaranCliente');
        }
    }

    protected function createViewsAlbaranes(string $viewName = 'ListAlbaranCliente'): void
    {
        $this->createViewSales($viewName, 'AlbaranCliente', 'delivery-notes');

        // agrupamos las acciones secundarias en un dropdown
        $this->tab($viewName)->addButtonGroup([
            'name' => 'doc-actions',
            'icon' => 'fa-solid fa-circle-check',
            'label' => 'actions'
        ]);
        $this->addButtonApproveDocument($viewName, 'doc-actions');
        $this->addButtonGroupDocument($viewName, 'doc-actions');

        $paises = Paises::codeModel();
        $this->addFilterSelect($viewName, 'country', 'country', 'codpais', $paises);
        $this->addFilterSelectAuto($viewName, 'provincia', 'province', 'provincia', 'provincias');
        $this->addFilterSelectAuto($viewName, 'ciudad', 'city', 'ciudad', 'ciudades');
    }
}
