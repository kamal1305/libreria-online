<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2026 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Core\Controller;

use FacturaScripts\Core\Lib\Accounting\ClosingToAcounting;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\Accounting\AccountingPlanExport;
use FacturaScripts\Dinamic\Lib\Accounting\AccountingPlanImport;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\Cuenta;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\Familia;
use FacturaScripts\Dinamic\Model\GrupoClientes;
use FacturaScripts\Dinamic\Model\Impuesto;
use FacturaScripts\Dinamic\Model\Producto;
use FacturaScripts\Dinamic\Model\Proveedor;
use FacturaScripts\Dinamic\Model\Retencion;
use FacturaScripts\Dinamic\Model\WorkEvent;

/**
 * Controlador para editar un único elemento del modelo Ejercicio
 *
 * @author Carlos García Gómez           <carlos@facturascripts.com>
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 * @author Francesc Pineda Segarra       <francesc.pineda.segarra@gmail.com>
 * @author Oscar G. Villa González       <ogvilla@gmail.com>
 */
class EditEjercicio extends EditController
{
    public function getModelClassName(): string
    {
        return 'Ejercicio';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'accounting';
        $data['title'] = 'exercise';
        $data['icon'] = 'fa-solid fa-calendar-alt';
        return $data;
    }

    /**
     * Add action buttons.
     */
    protected function addExerciseActionButtons(string $viewName): void
    {
        // si el ejercicio todavía no existe, no añadimos botones
        $codejercicio = $this->tabModelValue($viewName, 'codejercicio');
        if (empty($codejercicio)) {
            return;
        }

        $hasAccounts = Cuenta::count([Where::eq('codejercicio', $codejercicio)]) > 0;

        // el plan contable solamente se puede exportar cuando hay cuentas
        if ($hasAccounts) {
            $this->tab($viewName)->addButton([
                'row' => 'footer-actions',
                'action' => 'export-accounting',
                'color' => 'info',
                'icon' => 'fa-solid fa-file-export',
                'label' => 'export',
                'type' => 'action'
            ]);
        }

        $status = $this->tabModelValue($viewName, 'estado');
        switch ($status) {
            case Ejercicio::EXERCISE_STATUS_OPEN:
                // y solamente se puede importar cuando no hay cuentas
                if (false === $hasAccounts) {
                    $this->tab($viewName)->addButton([
                        'row' => 'footer-actions',
                        'action' => 'import-accounting',
                        'color' => 'warning',
                        'icon' => 'fa-solid fa-file-import',
                        'label' => 'import-accounting-plan',
                        'type' => 'modal'
                    ]);
                }

                $this->tab($viewName)->addButton([
                    'row' => 'footer-actions',
                    'action' => 'close-exercise',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-lock',
                    'label' => 'close-exercise',
                    'type' => 'modal'
                ]);
                break;

            case Ejercicio::EXERCISE_STATUS_CLOSED:
                $this->tab($viewName)->addButton([
                    'row' => 'footer-actions',
                    'action' => 'open-exercise',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-lock-open',
                    'label' => 'open-exercise',
                    'type' => 'modal'
                ]);
                break;
        }
    }

    /**
     * Informa al usuario si todavía hay eventos en la cola de trabajo
     * recalculando los saldos de cuentas y subcuentas.
     */
    private function checkPendingBalanceJobs(): void
    {
        $where = [
            Where::eq('done', false),
            Where::in('name', [
                'Model.Partida.Save',
                'Model.Partida.Delete',
                'Model.Subcuenta.Update',
                'Model.Subcuenta.Delete',
                'Model.Cuenta.Update',
                'Model.Cuenta.Delete',
            ]),
        ];

        $pending = WorkEvent::count($where);
        if ($pending > 0) {
            Tools::log()->warning('balances-updating-in-background', ['%count%' => $pending]);
        }
    }

    /**
     * Avisa si hay códigos de subcuenta configurados con una longitud distinta
     * a la definida en el ejercicio.
     */
    protected function checkConfiguredSubaccountLengths(int $length, int $idempresa): void
    {
        $config = [
            [Producto::class, 'products', ['codsubcuentacom', 'codsubcuentairpfcom', 'codsubcuentaven'], []],
            [Familia::class, 'families', ['codsubcuentacom', 'codsubcuentairpfcom', 'codsubcuentaven'], []],
            [Impuesto::class, 'taxes', [
                'codsubcuentarep',
                'codsubcuentarepintra',
                'codsubcuentarepre',
                'codsubcuentasop',
                'codsubcuentasopintra',
                'codsubcuentasopre',
            ], []],
            [Retencion::class, 'retentions', ['codsubcuentaret', 'codsubcuentaacr'], []],
            [Cliente::class, 'customers', ['codsubcuenta'], []],
            [GrupoClientes::class, 'customer-groups', ['codsubcuenta'], []],
            [Proveedor::class, 'suppliers', ['codsubcuenta'], []],
            [CuentaBanco::class, 'bank-accounts', ['codsubcuenta', 'codsubcuentagasto'], [
                Where::eq('idempresa', $idempresa),
            ]],
        ];

        $count = 0;
        $labels = [];
        foreach ($config as [$modelClass, $label, $fields, $where]) {
            $modelCount = $this->countWrongLengthSubaccounts($modelClass, $fields, $length, $where);
            if ($modelCount > 0) {
                $count += $modelCount;
                $labels[] = Tools::trans($label);
            }
        }

        if ($count > 0) {
            Tools::log()->warning('configured-subaccounts-wrong-length', [
                '%count%' => $count,
                '%length%' => $length,
                '%models%' => implode(', ', $labels),
            ]);
        }
    }

    /**
     * Cuenta los campos no vacíos cuya longitud no coincide con la indicada.
     */
    protected function countWrongLengthSubaccounts(
        string $modelClass,
        array $fields,
        int $length,
        array $where = []
    ): int {
        $count = 0;
        foreach ($fields as $field) {
            $fieldWhere = array_merge($where, [
                Where::notEq($field, ''),
                Where::notEq('LENGTH(' . $field . ')', $length),
            ]);
            $count += $modelClass::count($fieldWhere);
        }

        return $count;
    }

    private function checkAndLoad(string $code): bool
    {
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return false;
        }

        if (false === $this->getModel()->loadFromCode($code)) {
            Tools::log()->error('record-not-found');
            return false;
        }

        return true;
    }

    protected function closeExerciseAction(): bool
    {
        $code = $this->request->input('codejercicio');
        if (false === $this->checkAndLoad($code)) {
            return true;
        }

        $data = [
            'journalClosing' => $this->request->input('iddiario-closing'),
            'journalOpening' => $this->request->input('iddiario-opening'),
            'copySubAccounts' => (bool)$this->request->input('copysubaccounts', false)
        ];

        $model = $this->getModel();
        $closing = new ClosingToAcounting();
        if ($closing->exec($model, $data)) {
            Tools::log()->notice('closing-accounting-completed');
        }
        // error message not needed
        return true;
    }

    /**
     * Load views.
     */
    protected function createViews()
    {
        parent::createViews();

        // disable company column if there is only one company
        if ($this->empresa->count() < 2) {
            $this->mainTab()->disableColumn('company');
        }

        $this->createViewsAccounting();
        $this->createViewsSubaccounting();
        $this->createViewsAccountingEntries();
    }

    protected function createViewsAccounting(string $viewName = 'ListCuenta'): void
    {
        $this->addListView($viewName, 'Cuenta', 'accounts', 'fa-solid fa-book')
            ->addOrderBy(['codcuenta'], 'code', 1)
            ->addSearchFields(['codcuenta', 'descripcion'])
            ->disableColumn('fiscal-exercise')
            ->disableColumn('parent-account');
    }

    protected function createViewsAccountingEntries(string $viewName = 'ListAsiento'): void
    {
        $this->addListView($viewName, 'Asiento', 'special-accounting-entries', 'fa-solid fa-balance-scale')
            ->addOrderBy(['fecha', 'numero'], 'date')
            ->addSearchFields(['concepto', 'numero'])
            ->disableColumn('exercise')
            ->setSettings('btnNew', false);
    }

    protected function createViewsSubaccounting(string $viewName = 'ListSubcuenta'): void
    {
        $this->addListView($viewName, 'Subcuenta', 'subaccounts')
            ->addOrderBy(['codsubcuenta'], 'code', 1)
            ->addOrderBy(['saldo'], 'balance')
            ->addSearchFields(['codsubcuenta', 'descripcion'])
            ->disableColumn('fiscal-exercise');
    }

    /**
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'close-exercise':
                return $this->closeExerciseAction();

            case 'export-accounting':
                return $this->exportAccountingPlan();

            case 'import-accounting':
                return $this->importAccountingPlan();

            case 'open-exercise':
                return $this->openExerciseAction();
        }

        return parent::execPreviousAction($action);
    }

    /**
     * Export AccountingPlan to CSV file.
     *
     * @return bool
     */
    protected function exportAccountingPlan(): bool
    {
        if (false === $this->permissions->allowImport) {
            Tools::log()->warning('no-print-permission');
            return true;
        }

        $codejercicio = $this->request->queryOrInput('code', '');
        if (empty($codejercicio)) {
            Tools::log()->error('exercise-not-found');
            return true;
        }

        $this->setTemplate(false);

        $accountingPlanExport = new AccountingPlanExport();

        $this->response
            ->header('Content-Type', 'text/csv; charset=utf-8')
            ->header('Content-Disposition', 'attachment;filename=' . $codejercicio . '.csv')
            ->setContent($accountingPlanExport->exportCSV($codejercicio));
        return false;
    }

    /**
     * Import AccountingPlan from any supported file type.
     *
     * @return bool
     */
    protected function importAccountingPlan(): bool
    {
        if (false === $this->permissions->allowImport) {
            Tools::log()->warning('no-import-permission');
            return true;
        }

        $codejercicio = $this->request->input('codejercicio', '');
        if (empty($codejercicio)) {
            Tools::log()->error('exercise-not-found');
            return true;
        }

        // no se puede importar si el ejercicio ya tiene cuentas
        if (Cuenta::count([Where::eq('codejercicio', $codejercicio)]) > 0) {
            Tools::log()->error('exercise-already-has-accounting-plan', ['%code%' => $codejercicio]);
            return true;
        }

        $length = (int)$this->request->input('longsubcuenta', 0);

        $uploadFile = $this->request->files->get('accountingfile');
        if (empty($uploadFile)) {
            return $this->importDefaultPlan($codejercicio, $length);
        }

        $accountingPlanImport = new AccountingPlanImport();
        switch ($uploadFile->getMimeType()) {
            case 'application/xml':
            case 'text/xml':
                if ($accountingPlanImport->importXML($uploadFile->getPathname(), $codejercicio, $length)) {
                    Tools::log()->notice('record-updated-correctly');
                    return true;
                }
                Tools::log()->error('record-save-error');
                return true;

            case 'text/csv':
            case 'text/plain':
                if ($accountingPlanImport->importCSV($uploadFile->getPathname(), $codejercicio, $length)) {
                    Tools::log()->notice('record-updated-correctly');
                    return true;
                }
                Tools::log()->error('record-save-error');
                return true;
        }

        Tools::log()->error('file-not-supported');
        return true;
    }

    protected function importDefaultPlan(string $codejercicio, int $length = 0): bool
    {
        $filePath = FS_FOLDER . '/Dinamic/Data/Lang/' . Tools::config('lang') . '/defaultPlan.csv';
        if (false === file_exists($filePath)) {
            $codpais = Tools::settings('default', 'codpais');
            $filePath = FS_FOLDER . '/Dinamic/Data/Codpais/' . $codpais . '/defaultPlan.csv';
        }

        if (false === file_exists($filePath)) {
            Tools::log()->warning('file-not-found', ['%fileName%' => $filePath]);
            return true;
        }

        $accountingPlanImport = new AccountingPlanImport();
        if ($accountingPlanImport->importCSV($filePath, $codejercicio, $length)) {
            Tools::log()->notice('record-updated-correctly');
            return true;
        }

        Tools::log()->error('record-save-error');
        return true;
    }

    /**
     * Load view data procedure
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $codejercicio = $this->tabModelValue('EditEjercicio', 'codejercicio');

        switch ($viewName) {
            case 'EditEjercicio':
                parent::loadData($viewName, $view);
                $this->addExerciseActionButtons($viewName);
                $this->checkPendingBalanceJobs();
                break;

            case 'ListAsiento':
                $where = [
                    Where::eq('codejercicio', $codejercicio),
                    Where::isNotNull('operacion')
                ];
                $view->loadData('', $where);
                break;

            case 'ListCuenta':
            case 'ListSubcuenta':
                $where = [Where::eq('codejercicio', $codejercicio)];
                $view->loadData('', $where);

                // ocultamos la columna saldo de los totales
                unset($view->totalAmounts['saldo']);

                // si hay cuentas o subcuentas, ponemos readonly los campos longsubcuenta, fechainicio y fechafin
                if ($view->count > 0) {
                    $this->tab('EditEjercicio')
                        ->disableColumn('account-length', false, 'true')
                        ->disableColumn('start-date', false, 'true')
                        ->disableColumn('end-date', false, 'true');
                }

                if ($viewName === 'ListSubcuenta' && $view->count > 0) {
                    $length = (int)$this->tabModelValue('EditEjercicio', 'longsubcuenta');
                    $idempresa = (int)$this->tabModelValue('EditEjercicio', 'idempresa');
                    $this->checkConfiguredSubaccountLengths($length, $idempresa);
                }
                break;
        }
    }

    /**
     * Re-open closed exercise.
     *
     * @return bool
     */
    protected function openExerciseAction(): bool
    {
        $code = $this->request->input('codejercicio');
        if (false === $this->checkAndLoad($code)) {
            return true;
        }

        $data = [
            'deleteClosing' => (bool)$this->request->input('delete-closing'),
            'deleteOpening' => (bool)$this->request->input('delete-opening')
        ];
        $model = $this->getModel();

        $closing = new ClosingToAcounting();
        if ($closing->delete($model, $data)) {
            Tools::log()->notice('opening-acounting-completed');
        }

        // error message not needed
        return true;
    }
}
